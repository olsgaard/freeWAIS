/* dist-3.0 - 18 Aug 1993 */

#define VERSION 2.2
#define PATCHLEVEL 0
