ldflags='-lsocket -lnsl'
