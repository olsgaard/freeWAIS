# -O is broken on Linux
optimize=' -O2 -fno-strength-reduce -m486';
d_strdup='define';
cc='gcc' ;
