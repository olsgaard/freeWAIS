/*                               -*- Mode: C -*- 
 * $Basename: display.h $
 * $Revision: 1.8.1.3 $
 * Author          : jonathan@Think.COM
 * Created On      : 92/03/17  14:23:29
 * Last Modified By: Ulrich Pfeifer
 * Last Modified On: Mon May  5 09:49:04 1997
 * Language        : C
 * Update Count    : 1
 * Status          : Unknown, Use with caution!
 * 
 * (C) Copyright 1997, Universit�t Dortmund, all rights reserved.
 * (C) Copyright CNIDR (see ../doc/CNIDR/COPYRIGHT)
 */

#ifndef _H_DISPLAY
#define _H_DISPLAY
Widget SetupWaisDisplay _AP((Widget parent));
#endif

