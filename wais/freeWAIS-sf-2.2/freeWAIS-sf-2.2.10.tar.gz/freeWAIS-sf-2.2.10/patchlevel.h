/* dist-3.0 - 18 Aug 1993 */
/* $Format: "#define VERSION $ProjectMajorVersion$"$ */
#define VERSION 2.2
/* $Format: "#define PATCHLEVEL $ProjectMinorVersion$"$ */
#define PATCHLEVEL 10
