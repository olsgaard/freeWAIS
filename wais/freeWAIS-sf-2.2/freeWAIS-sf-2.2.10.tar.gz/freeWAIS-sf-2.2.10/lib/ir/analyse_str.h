/*                               -*- Mode: C -*- 
 * $Basename: analyse_str.h $
 * $Revision: 1.1.1.1 $
 * Author          : Huynh Quoc T. Tung
 * Created On      : Sun Oct 17 16:43:47 1993
 * Last Modified By: Ulrich Pfeifer
 * Last Modified On: Mon May  5 17:29:55 1997
 * Language        : C
 * Update Count    : 17
 * Status          : Unknown, Use with caution!
 * 
 * (C) Copyright 1997, Universit�t Dortmund, all rights reserved.
 * 
 */


char* analyse_string _AP((char* line, long* number_of_fields, int* global_dictionary_exists));

