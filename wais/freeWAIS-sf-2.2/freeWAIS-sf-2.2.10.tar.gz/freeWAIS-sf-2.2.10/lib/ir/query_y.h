typedef union {
   int  ival;
   char *sval;
   } YYSTYPE;
#define	WORD	258
#define	PHONIX	259
#define	SOUNDEX	260
#define	ASSIGN	261
#define	FLOAT	262
#define	OR	263
#define	AND	264
#define	NOT	265
#define	PROX_ORDERED	266
#define	PROX_UNORDERED	267
#define	PROX_ATLEAST	268


extern YYSTYPE querylval;
