/*                               -*- Mode: C -*- 
 * field.h -- 
 * ITIID           : $ITI$ $Header $__Header$
 * Author          : Ulrich Pfeifer
 * Created On      : Thu Mar  3 14:10:12 1994
 * Last Modified By: Ulrich Pfeifer
 * Last Modified On: Wed Sep  6 10:38:19 1995
 * Update Count    : 3
 * Status          : Unknown, Use with caution!
 */

#ifndef FIELD_H
#define FIELD_H
long init_add_fields _AP((char* name, boolean* global_dictionary_exists, database *db));
#endif
